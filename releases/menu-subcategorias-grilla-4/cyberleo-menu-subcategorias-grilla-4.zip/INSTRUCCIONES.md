# Menú Productos + grilla 4 columnas

Extraer sobre `public_html` (sobrescribe estos archivos).

## Archivos
- includes/public_nav.php
- includes/catalog_display.php
- includes/catalog_taxonomy.php
- components/nav.php
- components/footer.php
- components/home_featured.php
- components/product_card.php
- category.php
- offers.php
- assets/css/style.css
- assets/js/public-nav.js
- assets/js/catalog-preview.js
- admin_settings.php

## Después de subir
1. Conservar `includes/config.local.php`.
2. Reiniciar PHP / Purge LiteSpeed.
3. Admin → Ajustes → Columnas destacados = 4 y Columnas catálogo = 4 → Guardar
   (o ejecutar `set-catalog-columns-4.sql` si preferís SQL).
4. Ctrl+F5 en la tienda.

## Rollback
Restaurar el backup previo de los mismos paths.
